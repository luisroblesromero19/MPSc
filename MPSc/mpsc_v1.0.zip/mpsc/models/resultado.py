"""
MPSc — models/resultado.py
Clase Resultado: encapsula el índice de compatibilidad final.
"""
from dataclasses import dataclass, field


@dataclass
class Resultado:
    nombre_jugador: str = ""
    nombre_club: str = ""
    valor_mercado: str = ""
    perfil_evaluacion: str = ""

    compatibilidades: dict = field(default_factory=dict)
    scores_jugador: dict = field(default_factory=dict)
    scores_club: dict = field(default_factory=dict)

    score_rendimiento_inmediato: float = 0.0
    score_potencial_mediano: float = 0.0
    score_bajo_riesgo: float = 0.0
    score_final: float = 0.0

    def interpretacion(self) -> str:
        s = self.score_final
        if s >= 85:
            return "MUY ALTA — Candidato prioritario"
        elif s >= 70:
            return "ALTA — Candidato recomendado"
        elif s >= 55:
            return "MODERADA — Candidato con reservas"
        elif s >= 40:
            return "BAJA — Brechas importantes"
        else:
            return "MUY BAJA — No recomendado"

    def color_interpretacion(self) -> str:
        s = self.score_final
        if s >= 85:   return "#22c55e"
        elif s >= 70: return "#84cc16"
        elif s >= 55: return "#f59e0b"
        elif s >= 40: return "#f97316"
        else:         return "#ef4444"
